CREATE PROCEDURE [dbo].[sp_AddBIAnalysisServer] 
 @serverInstanceName NVARCHAR(64), 
 @recId BIGINT 
 AS 
 BEGIN 
  SET NOCOUNT ON; 
  DECLARE @isDefault AS INT 
  IF (@serverInstanceName IS NOT NULL AND @serverInstanceName  <> '') 
  BEGIN
    IF (COL_LENGTH('[dbo].[BIANALYSISSERVER]', '[PARTITIONS]') IS NULL)
    BEGIN 
	  /* Handle minor version upgrade scenario where partition column does not exist yet */
      IF (SELECT COUNT(RECID) FROM BIANALYSISSERVER WHERE SERVERNAME = @serverInstanceName) = 0 
	  BEGIN 
	    SELECT @isDefault = 1 
		IF (SELECT COUNT(ISDEFAULT) FROM [BIANALYSISSERVER] WHERE [ISDEFAULT] = 1) > 0 
		BEGIN 
			SELECT @isDefault = 0 
        END 
        INSERT INTO [dbo].[BIANALYSISSERVER]
             ([SERVERNAME],[DESCRIPTION],[ISVALID],[ISDEFAULT],[DEFAULTDATABASENAME],[RECID],[RECVERSION]) 
        VALUES 
             (@serverInstanceName,'',1,@isDefault,'',@recId, 1) 
      END       
 	END
    ELSE    
	BEGIN
	  IF (SELECT COUNT(RECID) FROM BIANALYSISSERVER WHERE [PARTITIONS] = 0 AND SERVERNAME = @serverInstanceName) = 0 
	  BEGIN 
		SELECT @isDefault = 1 
		IF (SELECT COUNT(ISDEFAULT) FROM [BIANALYSISSERVER] WHERE [PARTITIONS] = 0 AND [ISDEFAULT] = 1) > 0 
		BEGIN 
			SELECT @isDefault = 0 
        END 
        INSERT INTO [dbo].[BIANALYSISSERVER]
             ([SERVERNAME],[DESCRIPTION],[ISVALID],[ISDEFAULT],[DEFAULTDATABASENAME],[PARTITIONS],[RECID],[RECVERSION]) 
         VALUES 
             (@serverInstanceName,'',1,@isDefault,'',0,@recId, 1) 
	  END
    END 
  END 
 END