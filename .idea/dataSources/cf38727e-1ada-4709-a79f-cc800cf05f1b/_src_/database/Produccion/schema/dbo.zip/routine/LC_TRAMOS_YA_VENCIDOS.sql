CREATE PROCEDURE dbo.LC_TRAMOS_YA_VENCIDOS
AS
BEGIN
SET NOCOUNT ON;

DECLARE
@i integer  =  1,
@j integer  =  1,
@k integer  =  1,  
@QTY integer,
@MAX integer,
@accountnum nvarchar(20),
  @jchar nvarchar(20),
@grupoDias nvarchar(20);



IF OBJECT_ID('tempdb..#LC_TRAMOS_YA_VENCIDOS_PIVOT_1') IS NOT NULL
    BEGIN
        DROP TABLE #LC_TRAMOS_YA_VENCIDOS_PIVOT_1
    END

IF OBJECT_ID('tempdb..#LC_TRAMOS_YA_VENCIDOS_PIVOT') IS NOT NULL
    BEGIN
        DROP TABLE #LC_TRAMOS_YA_VENCIDOS_PIVOT
    END

IF OBJECT_ID('tempdb..#LC_TRAMOS_YA_VENCIDOS_CLIENTES') IS NOT NULL
    BEGIN
        DROP TABLE #LC_TRAMOS_YA_VENCIDOS_CLIENTES
    END


CREATE TABLE #LC_TRAMOS_YA_VENCIDOS_CLIENTES
(
 ID int IDENTITY(1,1) NOT NULL,
 ACCOUNTNUM nvarchar(20) COLLATE Latin1_General_CI_AS NOT NULL
)


CREATE TABLE #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 (
  ID int IDENTITY(1,1) NOT NULL,	
  ROWPERGRUPODIAS INTEGER NOT NULL,
  ACCOUNTNUM nvarchar(20) COLLATE Latin1_General_CI_AS NOT NULL,
  nombre_cliente nvarchar(100) COLLATE Latin1_General_CI_AS NULL,
  GRUPODIAS varchar(15) COLLATE Latin1_General_CI_AS NULL,
  INVOICE nvarchar(20),
  VOUCHER nvarchar(20),
  SALDO numeric(34, 16) NULL
)

CREATE TABLE #LC_TRAMOS_YA_VENCIDOS_PIVOT (
  ID int IDENTITY(1,1) NOT NULL,	
  ACCOUNTNUM nvarchar(20) COLLATE Latin1_General_CI_AS NOT NULL,
  nombre_cliente nvarchar(100) COLLATE Latin1_General_CI_AS NULL,
  dias15 nvarchar(300) NULL,
  dias30 nvarchar(300) NULL,
  dias45 nvarchar(300) NULL,
  dias60 nvarchar(300) NULL,
  dias90 nvarchar(300) NULL,
  dias120 nvarchar(300) NULL,
  Mas_de_120_dias nvarchar(300) NULL
)



INSERT INTO #LC_TRAMOS_YA_VENCIDOS_PIVOT_1
(
 ROWPERGRUPODIAS ,
 ACCOUNTNUM ,
 nombre_cliente ,
 GRUPODIAS ,
 INVOICE ,
 VOUCHER ,
 SALDO 
)
SELECT DISTINCT
  ROW_NUMBER() OVER(PARTITION BY LC_VISTA_TRAMOS_YA_VENCIDOS.ACCOUNTNUM,LC_VISTA_TRAMOS_YA_VENCIDOS.GRUPODIAS ORDER BY LC_VISTA_TRAMOS_YA_VENCIDOS.ACCOUNTNUM,LC_VISTA_TRAMOS_YA_VENCIDOS.GRUPODIAS) AS RowNumber,
  LC_VISTA_TRAMOS_YA_VENCIDOS.ACCOUNTNUM,
  LC_VISTA_TRAMOS_YA_VENCIDOS.nombre_cliente, 
  LC_VISTA_TRAMOS_YA_VENCIDOS.GRUPODIAS,
  LC_VISTA_TRAMOS_YA_VENCIDOS.INVOICE,
  LC_VISTA_TRAMOS_YA_VENCIDOS.VOUCHER,
  LC_VISTA_TRAMOS_YA_VENCIDOS.SALDO
  FROM
  LC_VISTA_TRAMOS_YA_VENCIDOS
  ORDER BY 
  LC_VISTA_TRAMOS_YA_VENCIDOS.ACCOUNTNUM;



INSERT INTO #LC_TRAMOS_YA_VENCIDOS_CLIENTES
(
ACCOUNTNUM
)

Select DISTINCT #LC_TRAMOS_YA_VENCIDOS_PIVOT_1.ACCOUNTNUM  from #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 ORDER BY ACCOUNTNUM;




Select @QTY=MAX(ID) from #LC_TRAMOS_YA_VENCIDOS_CLIENTES ;

  WHILE @i <=@QTY
  
  BEGIN
  
  Select @accountnum=ACCOUNTNUM from #LC_TRAMOS_YA_VENCIDOS_CLIENTES where ID=@i;
  SELECT @MAX=MAX(#LC_TRAMOS_YA_VENCIDOS_PIVOT_1.ROWPERGRUPODIAS) FROM  #LC_TRAMOS_YA_VENCIDOS_PIVOT_1  where  ACCOUNTNUM=@accountnum GROUP BY  #LC_TRAMOS_YA_VENCIDOS_PIVOT_1.ACCOUNTNUM;
  Select TOP 1 @grupoDias=GRUPODIAS  from  #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 where  ACCOUNTNUM=@accountnum  AND ROWPERGRUPODIAS=@MAX;
  
     
     WHILE @j <= @MAX
     
    BEGIN 
        	  
      SET @jchar=CONVERT(VARCHAR,@j);
	
    
      EXEC('Insert into #LC_TRAMOS_YA_VENCIDOS_PIVOT
                  (
                ACCOUNTNUM,
                nombre_cliente,'+
                @grupoDias+'
                )
            Select 
            #LC_TRAMOS_YA_VENCIDOS_PIVOT_1.ACCOUNTNUM,
            #LC_TRAMOS_YA_VENCIDOS_PIVOT_1.nombre_cliente,          
            CASE
            WHEN LEN(#LC_TRAMOS_YA_VENCIDOS_PIVOT_1.INVOICE)>0 THEN
              #LC_TRAMOS_YA_VENCIDOS_PIVOT_1.INVOICE +''||'' + CONVERT (varchar,#LC_TRAMOS_YA_VENCIDOS_PIVOT_1.SALDO)
            ELSE
              #LC_TRAMOS_YA_VENCIDOS_PIVOT_1.VOUCHER +''||'' + CONVERT (varchar,#LC_TRAMOS_YA_VENCIDOS_PIVOT_1.SALDO)
            END 
            from         	
            #LC_TRAMOS_YA_VENCIDOS_PIVOT_1
            where  ACCOUNTNUM='''+@accountnum+''' AND GRUPODIAS='''+@grupoDias+''' AND  ROWPERGRUPODIAS='+@jchar);
                    
          
        
       Select  @k = MAX(ID) from  #LC_TRAMOS_YA_VENCIDOS_PIVOT ;
      
        update t1
        SET 
        t1.dias15=CASE
            WHEN LEN(t2.INVOICE)>0 THEN
              t2.INVOICE +'||' + CONVERT (varchar,t2.SALDO)
            ELSE
              t2.VOUCHER +'||' + CONVERT (varchar,t2.SALDO)
            END
        FROM         
        #LC_TRAMOS_YA_VENCIDOS_PIVOT t1 
        INNER JOIN #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 t2 ON
        t2.ACCOUNTNUM=t1.ACCOUNTNUM AND
        t2.GRUPODIAS='dias15'           
        WHERE        
       	t1.ACCOUNTNUM=@accountnum AND
        t2.ROWPERGRUPODIAS=@j AND
        t1.ID=@k  
       
        
        
        update t1
        SET 
        t1.dias30=CASE
            WHEN LEN(t2.INVOICE)>0 THEN
              t2.INVOICE +'||' + CONVERT (varchar,t2.SALDO)
            ELSE
              t2.VOUCHER +'||' + CONVERT (varchar,t2.SALDO)
            END
        FROM         
        #LC_TRAMOS_YA_VENCIDOS_PIVOT t1       
        INNER JOIN #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 t2 ON
        t2.ACCOUNTNUM=t1.ACCOUNTNUM AND
        t2.GRUPODIAS='dias30' AND
        t2.ROWPERGRUPODIAS=@j 
        WHERE        
        t1.ACCOUNTNUM=@accountnum AND
        t1.ID=@k  
        
        
        
          update t1
        SET 
        t1.dias45=CASE
            WHEN LEN(t2.INVOICE)>0 THEN
              t2.INVOICE +'||' + CONVERT (varchar,t2.SALDO)
            ELSE
              t2.VOUCHER +'||' + CONVERT (varchar,t2.SALDO)
            END
        FROM         
        #LC_TRAMOS_YA_VENCIDOS_PIVOT t1 
        INNER JOIN #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 t2 ON
        t2.ACCOUNTNUM=t1.ACCOUNTNUM AND
        t2.GRUPODIAS='dias45' AND
        t2.ROWPERGRUPODIAS=@j 
        WHERE        
        t1.ACCOUNTNUM=@accountnum AND
        t1.ID=@k  
       
        
        
       update t1
        SET 
        t1.dias60=CASE
            WHEN LEN(t2.INVOICE)>0 THEN
              t2.INVOICE +'||' + CONVERT (varchar,t2.SALDO)
            ELSE
              t2.VOUCHER +'||' + CONVERT (varchar,t2.SALDO)
            END
        FROM         
        #LC_TRAMOS_YA_VENCIDOS_PIVOT t1 
        INNER JOIN #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 t2 ON
        t2.ACCOUNTNUM=t1.ACCOUNTNUM AND
        t2.GRUPODIAS='dias60' AND
        t2.ROWPERGRUPODIAS=@j 
        WHERE        
         t1.ACCOUNTNUM=@accountnum AND
         t1.ID=@k  
        
        
        
        update t1
        SET 
        t1.dias90=CASE
            WHEN LEN(t2.INVOICE)>0 THEN
              t2.INVOICE +'||' + CONVERT (varchar,t2.SALDO)
            ELSE
              t2.VOUCHER +'||' + CONVERT (varchar,t2.SALDO)
            END
        FROM         
        #LC_TRAMOS_YA_VENCIDOS_PIVOT t1 
        INNER JOIN #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 t2 ON
         t2.ACCOUNTNUM=t1.ACCOUNTNUM AND
        t2.GRUPODIAS='dias90' AND
        t2.ROWPERGRUPODIAS=@j
        WHERE        
        t1.ACCOUNTNUM=@accountnum AND
       t1.ID=@k  
        
        
        
        
          update t1
        SET 
        t1.dias120=CASE
            WHEN LEN(t2.INVOICE)>0 THEN
              t2.INVOICE +'||' + CONVERT (varchar,t2.SALDO)
            ELSE
              t2.VOUCHER +'||' + CONVERT (varchar,t2.SALDO)
            END
        FROM         
        #LC_TRAMOS_YA_VENCIDOS_PIVOT t1 
        INNER JOIN #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 t2 ON
        t2.ACCOUNTNUM=t1.ACCOUNTNUM AND
        t2.GRUPODIAS='dias120' AND
        t2.ROWPERGRUPODIAS=@j
        WHERE        
        t1.ACCOUNTNUM=@accountnum AND
        t1.ID=@k       
             
        
        
        
         update t1
        SET 
        t1.Mas_de_120_dias=CASE
            WHEN LEN(t2.INVOICE)>0 THEN
              t2.INVOICE +'||' + CONVERT (varchar,t2.SALDO)
            ELSE
              t2.VOUCHER +'||' + CONVERT (varchar,t2.SALDO)
            END
        FROM         
        #LC_TRAMOS_YA_VENCIDOS_PIVOT t1 
        INNER JOIN #LC_TRAMOS_YA_VENCIDOS_PIVOT_1 t2 ON
        t2.ACCOUNTNUM=t1.ACCOUNTNUM AND
        t2.GRUPODIAS='Mas_de_120_dias' AND
        t2.ROWPERGRUPODIAS=@j 
        WHERE        
        t1.ACCOUNTNUM=@accountnum AND
        t1.ID=@k
     
    
    
          SET @j  =  @j  +  1; 
        END
        	
     
  	  SET @j=1;
  
  
     SET @i  =  @i  +  1;
  
  END;

Select *  from #LC_TRAMOS_YA_VENCIDOS_PIVOT ORDER BY ACCOUNTNUM;



IF OBJECT_ID('tempdb..#LC_TRAMOS_YA_VENCIDOS_PIVOT_1') IS NOT NULL
    BEGIN
        DROP TABLE #LC_TRAMOS_YA_VENCIDOS_PIVOT_1
    END

IF OBJECT_ID('tempdb..#LC_TRAMOS_YA_VENCIDOS_PIVOT') IS NOT NULL
    BEGIN
        DROP TABLE #LC_TRAMOS_YA_VENCIDOS_PIVOT
    END

IF OBJECT_ID('tempdb..#LC_TRAMOS_YA_VENCIDOS_CLIENTES') IS NOT NULL
    BEGIN
        DROP TABLE #LC_TRAMOS_YA_VENCIDOS_CLIENTES
    END


END
