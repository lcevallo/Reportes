CREATE PROCEDURE dbo.LC_CXC_INFO_CLIENTE
AS
BEGIN
SET NOCOUNT ON;

DECLARE @registros int,
@i int  =  1,
@ACCOUNTNUM nvarchar(20),
@dirpartytableRECID bigint,
@mail nvarchar(255),
@NOMBRE_CLIENTE nvarchar(100),
@telefono nvarchar(255);


IF OBJECT_ID('tempdb..#TMPCXCINFOCLIENTE') IS NOT NULL
    BEGIN
        DROP TABLE #TMPCXCINFOCLIENTE
    END

SET @registros=0;

 CREATE TABLE #TMPCXCINFOCLIENTE
 (
  ID int IDENTITY(1,1) not null,
  ACCOUNTNUM nvarchar(20) NULL,
  NOMBRE_CLIENTE nvarchar(100),
  CREDITMAX numeric(32, 16),
  VATNUM  nvarchar(20),
  PaymSched nvarchar(30),
  PaymMode nvarchar(10),
  ADDRESS nvarchar(250),
  STREETNUMBER nvarchar(20),
  STREET nvarchar(250),
  CITY nvarchar(30),
  CANAL nvarchar(30),
  COUNTY nvarchar(10),
  STATE nvarchar(10),
  VENDEDOR nvarchar(100),
  MAIL nvarchar(255),
  TELEFONO nvarchar(255)
);

insert into #TMPCXCINFOCLIENTE
(
ACCOUNTNUM,
CREDITMAX,
VATNUM,
PaymSched,
PaymMode,
ADDRESS,
STREETNUMBER,
STREET,
CITY,
COUNTY,
STATE,
VENDEDOR,
CANAL
)
SELECT 
  custtable.ACCOUNTNUM
  ,custtable.CREDITMAX
  ,custtable.VATNUM
  ,CUSTTABLE.PaymSched
  ,CUSTTABLE.PaymMode
  ,DirPartyPostalAddressView.ADDRESS
  ,DirPartyPostalAddressView.STREETNUMBER
  ,DirPartyPostalAddressView.STREET
  ,DirPartyPostalAddressView.CITY
  ,DirPartyPostalAddressView.COUNTY
  ,DirPartyPostalAddressView.STATE
  ,[VENDEDOR]=
  ( select
  	DirPartyTable.NAME 
  	from 
	DirPartyTable
	where
	DirPartyTable.RECID in 
    (Select PERSON from  hcmWorker where hcmWorker.RECID=custtable.MAINCONTACTWORKER )
	)
  ,[CANAL]=
  (Select 
     DEFAULTDIMENSIONVIEW.DISPLAYVALUE 
     from DEFAULTDIMENSIONVIEW 
     where 
     CUSTTABLE.DEFAULTDIMENSION=DEFAULTDIMENSIONVIEW.DEFAULTDIMENSION
     AND
     DEFAULTDIMENSIONVIEW.NAME = 'CANAL_ALPH'
     )  
FROM
  DirPartyPostalAddressView
  INNER JOIN custtable ON (DirPartyPostalAddressView.PARTY = custtable.PARTY)
  where
  custtable.DATAAREAID='alph'




Select @registros= MAX(ID) from #TMPCXCINFOCLIENTE;
--Ahora si sin usar cursor 

WHILE @i <=@registros
BEGIN


Select @ACCOUNTNUM=ACCOUNTNUM from #TMPCXCINFOCLIENTE where ID=@i;


SELECT 
@dirpartytableRECID= dirpartytable.RECID,
@NOMBRE_CLIENTE=dirpartytable.NAME
FROM
  dirpartytable
  INNER JOIN Custtable ON (dirpartytable.RECID = Custtable.PARTY)
WHERE
  Custtable.ACCOUNTNUM = @ACCOUNTNUM
  AND
  Custtable.DATAAREAID='alph';


 SELECT 
 @mail= LogisticsElectronicAddress.LOCATOR
FROM
  DirpartyTable
  INNER JOIN LogisticsElectronicAddress ON (DirpartyTable.PRIMARYCONTACTEMAIL = LogisticsElectronicAddress.RECID)
WHERE
  DirpartyTable.RECID = @dirpartytableRECID
 -- AND
 -- DirpartyTable.DATAAREA='alph';
  
 
SELECT 
 @telefono=LogisticsElectronicAddress.LOCATOR
FROM
  DirpartyTable
  INNER JOIN LogisticsElectronicAddress ON (DirpartyTable.PRIMARYCONTACTPHONE = LogisticsElectronicAddress.RECID)
WHERE
 DirpartyTable.RECID = @dirpartytableRECID
 --   AND
 -- DirpartyTable.DATAAREA='alph'
  ;
  
  
  update #TMPCXCINFOCLIENTE
  SET 
	MAIL=@mail,
  	TELEFONO =@telefono,
    NOMBRE_CLIENTE=@NOMBRE_CLIENTE
    where 
  ID=@i AND
  ACCOUNTNUM = @ACCOUNTNUM;
  

SET @i  =  @i  +  1;
END



Select  * from #TMPCXCINFOCLIENTE

IF OBJECT_ID('tempdb..#TMPCXCINFOCLIENTE') IS NOT NULL
    BEGIN
        DROP TABLE #TMPCXCINFOCLIENTE
    END

END
