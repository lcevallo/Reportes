CREATE PROCEDURE [dbo].[sp_AddReportServer]
           @serverId nvarchar(60),
           @isDefault int,
           @serverUrl nvarchar(255),
           @axReportFolder nvarchar(255),
           @description nvarchar(60),
           @reportManagerUrl nvarchar(255),
           @sqlServerInstanceName nvarchar(16),
           @aosServerName nvarchar(255),
           @configurationId nvarchar(60),
           @isSharepointIntegrated int, 
           @recID BIGINT
AS
BEGIN
  SET NOCOUNT ON;
  
  DECLARE @aosInstanceName AS nvarchar(40);
  IF (@configurationId IS NOT NULL AND @configurationId <> '')
  BEGIN 
   
    IF NOT(@aosServerName IS NULL OR @aosServerName = '')
    BEGIN
		/* Pick the first 'active' AOS server, for the given aos server name*/ 
      SELECT TOP 1 @aosInstanceName = [INSTANCE_NAME] + N'@' + @aosServerName  from [SYSSERVERSESSIONS] WHERE [SYSSERVERSESSIONS].[AOSID] LIKE @aosServerName + N'@%' AND [STATUS] = 1;
    END
    
    /* Insert a row into out configuration table */  
    INSERT INTO [dbo].[SRSSERVERS]
           ([SERVERID]
           ,[SERVERURL]
           ,[ISDEFAULTREPORTLIBRARYSERVER]
           ,[AXAPTAREPORTFOLDER]
           ,[DESCRIPTION]
           ,[REPORTMANAGERURL]
           ,[SERVERINSTANCE]
           ,[AOSID]
           ,[CONFIGURATIONID]
           ,[ISSHAREPOINTINTEGRATED]
           ,[RECID])
    VALUES (@serverId, 
           @serverUrl,
           @isDefault,
           @axReportFolder,
           @description,
           @reportManagerUrl,
           @sqlServerInstanceName,
           @aosInstanceName, 
           @configurationId,
           @isSharepointIntegrated,
           @recID)    
  END
END