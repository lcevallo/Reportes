CREATE VIEW LC_VISTA_CXC_FECHAS_VENCIDAS_FACTURAS
AS
SELECT 
CustInvoiceJour.INVOICEACCOUNT,
CustInvoiceJour.InvoiceId,
CustInvoiceJour.SALESID,
CustInvoiceJour.InvoiceAmount,
(
SELECT Salestable.RECID
FROM
  Salestable
  WHERE Salestable.SALESID=CustInvoiceJour.SALESID
) AS RECID,
(
SELECT 
CUSTPAYMSCHED.RECID
FROM
  CUSTPAYMSCHED
  where
    CUSTPAYMSCHED.EXTTABLEID=366 AND
  CUSTPAYMSCHED.EXTRECID = (SELECT Salestable.RECID FROM  Salestable  WHERE Salestable.SALESID=CustInvoiceJour.SALESID)
) AS CUSTPAYMSCHED_RECID,
CustInvoiceJour.PaymentSched,
CAST (CustInvoiceJour.InvoiceDate AS DATE) AS InvoiceDate,
 CASE CustInvoiceJour.PaymentSched
 	WHEN '15' THEN 15
    WHEN '45' THEN 45
    WHEN '60-90-120' THEN 120
    WHEN '180' THEN 180
    WHEN '90' THEN 90
    WHEN  '150' THEN 150
    WHEN '306090120' THEN 120
    WHEN '30-60' THEN 60
    WHEN '120' THEN 120
    WHEN '30' THEN 30
    WHEN '60' THEN 60
    WHEN '30-60-90' THEN 90
    WHEN '00' THEN 0
    WHEN '15304560' THEN 60
    WHEN '153045607590' THEN 90
    WHEN '90-120' THEN 120
    END as CantMax,    
     CASE CustInvoiceJour.PaymentSched
 	WHEN '15' THEN DATEADD(day,15,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '45' THEN DATEADD(day,45,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '60-90-120' THEN DATEADD(day,120,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '180' THEN  DATEADD(day,180,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '90' THEN  DATEADD(day,90,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN  '150' THEN  DATEADD(day,150,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '306090120' THEN  DATEADD(day,120,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '30-60' THEN  DATEADD(day,60,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '120' THEN  DATEADD(day,120,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '30' THEN   DATEADD(day,30,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '60' THEN  DATEADD(day,60,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '30-60-90' THEN  DATEADD(day,90,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '00' THEN  DATEADD(day,0,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '15304560' THEN DATEADD(day,60,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '153045607590' THEN  DATEADD(day,90,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    WHEN '90-120' THEN DATEADD(day,120,CAST (CustInvoiceJour.InvoiceDate AS DATE))
    END as FECHAVENCIMIENTO
   
FROM
  CustInvoiceJour
  where
  CustInvoiceJour.DATAAREAID='alph'
