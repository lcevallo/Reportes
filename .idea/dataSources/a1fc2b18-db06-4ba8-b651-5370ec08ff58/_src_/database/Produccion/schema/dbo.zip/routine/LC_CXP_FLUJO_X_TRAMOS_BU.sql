CREATE PROCEDURE dbo.LC_CXP_FLUJO_X_TRAMOS_BU
AS
BEGIN
SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#TMP_CXP_FLUJO1') IS NOT NULL
    BEGIN
        DROP TABLE #TMP_CXP_FLUJO1
    END

SELECT
  VendTrans.ACCOUNTNUM,
  NOMBRE_CLIENTE=
   (
  SELECT 
  dbo.LC_VISTA_PROVEEDORES_ALPHA.NAME
FROM
  dbo.LC_VISTA_PROVEEDORES_ALPHA
  where
    dbo.LC_VISTA_PROVEEDORES_ALPHA.ACCOUNTNUM=VendTrans.ACCOUNTNUM
  )  ,  
 VendtransOpen.AMOUNTCUR,
 VendtransOpen.AMOUNTMST,
 CAST (VendtransOpen.TRANSDATE AS DATE) AS TRANSDATE,
 VendtransOpen.DUEDATE, 
(select
CAST(VendTable.PaymTermId AS INT)
from 
VendTable
where
VendTable.ACCOUNTNUM=VendTrans.ACCOUNTNUM
AND
VendTable.DATAAREAID='alph'
) as PaymTermId,
 VendTrans.INVOICE,
  VendTrans.TXT
  INTO #TMP_CXP_FLUJO1
  FROM
  VendTrans
  INNER JOIN VendtransOpen ON (VendTrans.ACCOUNTNUM = VendtransOpen.ACCOUNTNUM)
  AND (VendTrans.RECID = VendtransOpen.REFRECID)
  AND (VendTrans.DATAAREAID = VendtransOpen.DATAAREAID)
WHERE
  VendTrans.DATAAREAID = 'alph'
 -- AND
 --    vendtrans.ACCOUNTNUM='P000389'



Alter Table #TMP_CXP_FLUJO1 Add ID Int Identity(1, 1);
Alter Table #TMP_CXP_FLUJO1 Add FECHA_VENCIMIENTO DATE;
Alter Table #TMP_CXP_FLUJO1 Add diasVencidos int;


Alter Table #TMP_CXP_FLUJO1 Add Dias15 numeric(38, 16) NOT NULL DEFAULT 0.0;
Alter Table #TMP_CXP_FLUJO1 Add Dias1530 numeric(38, 16) NOT NULL DEFAULT 0.0;
Alter Table #TMP_CXP_FLUJO1 Add Dias3060 numeric(38, 16) NOT NULL DEFAULT 0.0;
Alter Table #TMP_CXP_FLUJO1 Add Dias6090 numeric(38, 16) NOT NULL DEFAULT 0.0;
Alter Table #TMP_CXP_FLUJO1 Add Dias90120 numeric(38, 16) NOT NULL DEFAULT 0.0;
Alter Table #TMP_CXP_FLUJO1 Add Dias120 numeric(38, 16) NOT NULL DEFAULT 0.0;
Alter Table #TMP_CXP_FLUJO1 Add XVencer numeric(38, 16) NOT NULL DEFAULT 0.0;


update #TMP_CXP_FLUJO1
SET FECHA_VENCIMIENTO=DATEADD(day, PaymTermId, TRANSDATE);

update #TMP_CXP_FLUJO1
SET diasVencidos=DATEDIFF(day,FECHA_VENCIMIENTO,GETDATE());


update #TMP_CXP_FLUJO1
set XVencer =AMOUNTCUR
where diasVencidos < 0;


update #TMP_CXP_FLUJO1
set Dias15 =AMOUNTCUR
where diasVencidos BETWEEN 0 AND 15;

update #TMP_CXP_FLUJO1
set Dias1530 =AMOUNTCUR
where diasVencidos BETWEEN 16 AND 30;

update #TMP_CXP_FLUJO1
set Dias3060 =AMOUNTCUR
where diasVencidos BETWEEN 31 AND 60;

update #TMP_CXP_FLUJO1
set Dias6090 =AMOUNTCUR
where diasVencidos BETWEEN 61 AND 90;

update #TMP_CXP_FLUJO1
set Dias90120 =AMOUNTCUR
where diasVencidos BETWEEN 91 AND 120;

update #TMP_CXP_FLUJO1
set Dias120 =AMOUNTCUR
where diasVencidos > 120;


Select *  from #TMP_CXP_FLUJO1;


IF OBJECT_ID('tempdb..#TMP_CXP_FLUJO1') IS NOT NULL
    BEGIN
        DROP TABLE #TMP_CXP_FLUJO1
    END


END
