CREATE VIEW dbo.LC_VISTA_TRAMOS_YA_VENCIDOS
 AS 
 SELECT
 ROW_NUMBER() OVER(PARTITION BY CusttransOpen.ACCOUNTNUM ORDER BY CusttransOpen.ACCOUNTNUM) AS RowNumber,
   CusttransOpen.ACCOUNTNUM,  
   (
  SELECT 
   DIRPARTYTABLE.NAME
FROM
  CUSTTABLE
  LEFT OUTER JOIN DIRPARTYTABLE ON (DIRPARTYTABLE.RECID = CUSTTABLE.PARTY)
WHERE
  CUSTTABLE.ACCOUNTNUM=CusttransOpen.ACCOUNTNUM
  and
  CUSTTABLE.DATAAREAID=CusttransOpen.DATAAREAID
  ) as nombre_cliente,
  Custtrans.INVOICE,  
  TIPO = CASE 
  WHEN (Custtrans.Voucher LIKE 'ADLCC%') THEN 'CHEQUE POSTFECHADO'  
  WHEN (Custtrans.Voucher LIKE 'ADNDCL%') THEN 'NOTA DE DEBITO INTERNA'
  ELSE 'FACTURA NO DOCUMENTADA' END,
   datediff(day,GETDATE(), custtransopen.duedate) dias_vencido,
   GRUPODIAS= CASE 
 --  WHEN datediff(day,GETDATE(), custtransopen.duedate) <= 0 THEN 'YA VENCIDOS'
   WHEN datediff(day,GETDATE(), custtransopen.duedate) BETWEEN -15 AND 0 THEN 'dias15'
   WHEN datediff(day,GETDATE(), custtransopen.duedate) BETWEEN -30 AND -16  THEN 'dias30'
   WHEN datediff(day,GETDATE(), custtransopen.duedate) BETWEEN -45 AND -31 THEN 'dias45'
   WHEN datediff(day,GETDATE(), custtransopen.duedate) BETWEEN -60 AND -46 THEN 'dias60'
   WHEN datediff(day,GETDATE(), custtransopen.duedate) BETWEEN -90 AND -61 THEN 'dias90'
   WHEN datediff(day,GETDATE(), custtransopen.duedate) BETWEEN -120 AND -91 THEN 'dias120'
   WHEN datediff(day,GETDATE(), custtransopen.duedate) < -120 THEN 'Mas_de_120_dias'
   END,      
  CusttransOpen.TRANSDATE,
  CusttransOpen.DUEDATE,
  DATEDIFF(day,CusttransOpen.TRANSDATE,CusttransOpen.DUEDATE) AS DiffDate,
  Custtrans.VOUCHER,
  CusttransOpen.AMOUNTCUR,  
  ISNULL(Custtrans.AMOUNTMST, 0) - (ISNULL(Custtrans.SETTLEAMOUNTMST, 0) - ISNULL(Custtrans.EXCHADJUSTMENT, 0)) AS SALDO
  
FROM
 CusttransOpen
  INNER JOIN Custtrans ON (CusttransOpen.ACCOUNTNUM = Custtrans.ACCOUNTNUM)
  AND (CusttransOpen.REFRECID = Custtrans.RECID)
  
WHERE
  CusttransOpen.DATAAREAID = 'alph'
  AND
  datediff(day,GETDATE(), custtransopen.duedate) <= 0
