CREATE FUNCTION dbo.LCObtenerFacturaRecursivas (
@VOUCHER nvarchar(20),
@LASTSETTLEVOUCHER nvarchar(20)
)
RETURNS nvarchar(20)
AS
BEGIN

  DECLARE @result nvarchar(20);
  DECLARE @LASTSETTLE nvarchar(20);
  DECLARE @VOUCHER2 nvarchar(20);
 
             IF LEN(@LASTSETTLEVOUCHER)=0
             
             BEGIN
                        SELECT 
                          @result = CUSTTRANS.INVOICE 
                          FROM
                            CUSTTRANS
                          WHERE
                          CUSTTRANS.LASTSETTLEVOUCHER=@VOUCHER;
             
             END
             
             ELSE
              BEGIN
              		
                      IF EXISTS (Select 1 from CUSTTRANS where CUSTTRANS.VOUCHER=@LASTSETTLEVOUCHER AND CUSTTRANS.LASTSETTLEVOUCHER!=@VOUCHER)
                            BEGIN
                                    Select 
                                    @VOUCHER2=CUSTTRANS.VOUCHER,
                                    @LASTSETTLE=CUSTTRANS.LASTSETTLEVOUCHER, 
                                    @result = CUSTTRANS.INVOICE 
                                    from CUSTTRANS 
                                    where 
                                    CUSTTRANS.VOUCHER=@LASTSETTLEVOUCHER
                                    AND
                                    CUSTTRANS.LASTSETTLEVOUCHER!=@VOUCHER;
                            END
                            
                            ELSE
                              BEGIN 
                                      Select 
                                      @VOUCHER2=CUSTTRANS.VOUCHER,
                                      @LASTSETTLE=CUSTTRANS.LASTSETTLEVOUCHER, 
                                      @result = CUSTTRANS.INVOICE 
                                      from CUSTTRANS 
                                      where 
                                      CUSTTRANS.VOUCHER=@LASTSETTLEVOUCHER;
                              
                              END
                            
                                    IF LEN(@result)=0  
                                      BEGIN
                                               --IF (@VOUCHER2=@LASTSETTLEVOUCHER) AND (@VOUCHER=@LASTSETTLE)
                                               IF  @@NESTLEVEL=31
                                                BEGIN
                                                   SET @result='REVERSO';
                                                END
                                                ELSE
                                                   BEGIN
                                                        SET @result=dbo.LCObtenerFacturaRecursivas(@VOUCHER2,@LASTSETTLE);
                                                   END;
                                      END
              
              
  END

  	RETURN @result;
		
    
    
END
