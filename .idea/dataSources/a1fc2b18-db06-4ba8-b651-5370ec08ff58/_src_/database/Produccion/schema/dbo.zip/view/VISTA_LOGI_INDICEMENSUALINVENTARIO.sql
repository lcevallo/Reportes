CREATE VIEW VISTA_LOGI_INDICEMENSUALINVENTARIO
AS
SELECT
 rownumber = ROW_NUMBER() OVER (ORDER BY(SELECT 10000)),
  inventsum.ITEMID,
  inventdim.INVENTLOCATIONID,
  SUM(inventsum.POSTEDQTY) AS suma_cantidad,
  inventsum.RESERVPHYSICAL,
  EcoResProductTranslation.NAME,
  (COALESCE (inventsum.POSTEDQTY,0) +
   COALESCE (inventsum.RECEIVED,0) + 
   COALESCE (inventsum.DEDUCTED,0) + 
   COALESCE (inventsum.REGISTERED,0) - 
   COALESCE (inventsum.PICKED,0)   
   ) AS physicalOnhand,
  (
  	(
    COALESCE (inventsum.POSTEDQTY,0) + 
    COALESCE (inventsum.RECEIVED,0) + 
    COALESCE (inventsum.DEDUCTED,0) + 
    COALESCE (inventsum.REGISTERED,0) - 
    COALESCE (inventsum.PICKED,0)
    ) -    
    COALESCE (inventsum.RESERVPHYSICAL,0)) AS availPhysicalCalculated,
   (
   	(COALESCE (inventsum.POSTEDQTY,0) + COALESCE (inventsum.RECEIVED,0) + COALESCE (inventsum.DEDUCTED,0) + COALESCE (inventsum.REGISTERED,0) - COALESCE (inventsum.PICKED,0)) - COALESCE (inventsum.RESERVPHYSICAL,0))+  ( COALESCE (inventsum.ORDERED,0) +  COALESCE (inventsum.ARRIVED,0) + COALESCE (inventsum.RESERVORDERED,0) -  COALESCE (inventsum.ONORDER,0) ) as totalDisponible
FROM
  inventsum
  LEFT OUTER JOIN inventdim ON (inventdim.INVENTDIMID = inventsum.INVENTDIMID)
  AND (inventdim.DATAAREAID = inventsum.DATAAREAID)
  LEFT OUTER JOIN inventtable ON (inventsum.ITEMID = inventtable.ITEMID)
  AND (inventsum.DATAAREAID = inventtable.DATAAREAID)
  INNER JOIN EcoResProductTranslation ON (inventtable.PRODUCT = EcoResProductTranslation.PRODUCT)
WHERE
--  inventsum.ITEMID = 'SLFCAMST' AND 
  inventdim.DATAAREAID = 'alph' AND 
  LEN(inventdim.INVENTLOCATIONID) > 0
  AND
  inventdim.INVENTLOCATIONID!='CUARENTENA'
GROUP BY
  inventsum.ITEMID,
  inventdim.INVENTLOCATIONID,
  inventsum.RESERVPHYSICAL,
  EcoResProductTranslation.NAME,
  inventsum.POSTEDQTY,
  inventsum.RECEIVED,
  inventsum.DEDUCTED,
  inventsum.REGISTERED,
  inventsum.PICKED,
  inventsum.ORDERED,
  inventsum.ARRIVED,
  inventsum.RESERVORDERED,
  inventsum.ONORDER
