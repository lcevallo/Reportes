CREATE PROCEDURE [dbo].[getNumInternal] 
    @numberid bigint,
    @globalTransId bigint,
    @RowIDNumber bigint,
    @UserId nvarchar(5),
    @sessionid int, 
    @sessionLoginDateTime datetime,
    @Partition bigint, 
    @nextValue int output 
AS                 
BEGIN
DECLARE @continuous int
DECLARE @nextListValue int
DECLARE @rowNumber bigint
DECLARE @inuse int
DECLARE @highest int
DECLARE @recVersion int
DECLARE @allowChangeUp int
DECLARE @increment int
   SET NOCOUNT ON
    SELECT @nextValue = 0  /* initialize to not found. */
    SELECT @nextListValue = 0 /* not found */
    SELECT @inuse = 1 /* inuse true by default */
    SELECT @highest = 0
    SELECT @allowChangeUp = 0
    SELECT @increment = 1
    /* Check for continous number, if continous process list */
    SELECT TOP 1 
	    @highest = [HIGHEST], 
		@nextValue = [NEXTREC], 
		@continuous = [CONTINUOUS], 
		@rowNumber = [RECID], 
		@inuse = [INUSE], 
		@allowChangeUp = [ALLOWCHANGEUP]
    FROM [dbo].[NUMBERSEQUENCETABLE] WITH (ROWLOCK,UPDLOCK) 
    WHERE [NUMBERSEQUENCETABLE].[RECID] = @numberid  
	IF @rowNumber > 0
	BEGIN
     IF @continuous > 0 /* continuous number, goto list first */
     BEGIN
         WHILE @nextListValue = 0
         BEGIN
             SELECT TOP 1 @nextListValue = [NEXTREC], @rowNumber = [RECID], @recVersion = [RECVERSION] 
                 FROM [dbo].[NUMBERSEQUENCELIST]
                 WHERE [NUMBERSEQUENCELIST].[PARTITION] = @Partition AND [NUMBERSEQUENCELIST].[NUMBERSEQUENCEID] = @numberid and [NUMBERSEQUENCELIST].[STATUS] = 0  /* Free = 0; */

             IF @nextListValue > 0
             BEGIN
                 UPDATE [dbo].[NUMBERSEQUENCELIST] SET
                            [STATUS] = 1,
                            [TRANSID] = @globalTransId,
                            [MODIFIEDTRANSACTIONID] = @globalTransId,
                            [USERID] = @UserId,
                            [MODIFIEDBY] = @UserId,
                            [SESSIONID] = @sessionid,
                            [SESSIONLOGINDATETIME] = @sessionLoginDateTime,
                            [RECVERSION] = @recVersion + 1
                 FROM [dbo].[NUMBERSEQUENCELIST] WHERE [RECID] = @rowNumber and [RECVERSION] = @recVersion

                 IF @@ROWCOUNT = 1
                     SELECT @nextValue = @nextListValue
                 ELSE
                    SELECT @nextListValue = 0
             END
             ELSE
                 IF @nextValue <= @highest
                 BEGIN
                     SELECT @nextListValue = 0
                     BREAK
                 END
                 ELSE
                 BEGIN /* Exceeded high limit, return not found */
                     SELECT @nextValue = 0
                     SELECT @nextListValue = -1
                 END
         END
     END

     IF @nextListValue = 0
     BEGIN
         IF (@allowChangeUp != 0)
         BEGIN
             WHILE (1=1)
             BEGIN
                 SELECT 0 FROM [dbo].[NUMBERSEQUENCELIST]
                 WHERE [NUMBERSEQUENCELIST].[PARTITION] = @Partition and 
                       [NUMBERSEQUENCELIST].[STATUS] = 3 and 
                       [NUMBERSEQUENCELIST].[NUMBERSEQUENCEID] = @numberid and 
                       [NUMBERSEQUENCELIST].[NEXTREC] = @nextValue

                 IF @@ROWCOUNT = 1
                 BEGIN
                         SELECT @nextValue = @nextValue + 1
                         SELECT @increment = @increment + 1
                 END
                 ELSE
                         BREAK
             END
        END

        INSERT [dbo].[NUMBERSEQUENCELIST] ([RECID], [RECVERSION],[STATUS], [TRANSID], [MODIFIEDBY], [USERID], [SESSIONID], [SESSIONLOGINDATETIME], [NUMBERSEQUENCEID], [NEXTREC],[PARTITION]) Values (
                @RowIDNumber,
                1,
                1,
                @globalTransId,
                @UserId,
                @UserId,
                @sessionid,
                @sessionLoginDateTime,
                @numberid,
                @nextValue,
                @Partition)
                
         UPDATE [dbo].[NUMBERSEQUENCETABLE] SET
                [MODIFIEDTRANSACTIONID] = @globalTransId,
                [NEXTREC] = [NEXTREC]+@increment, [INUSE] = 1
                FROM [dbo].[NUMBERSEQUENCETABLE] WHERE [RECID] = @numberid
     END
 END
 ELSE
     SELECT @nextValue = 0 /* error not supported so return null value. */
END