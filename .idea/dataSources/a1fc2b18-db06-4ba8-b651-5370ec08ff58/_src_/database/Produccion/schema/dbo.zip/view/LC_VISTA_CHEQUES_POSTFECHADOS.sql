CREATE VIEW LC_VISTA_CHEQUES_POSTFECHADOS
AS

WITH ORIGEN AS (
SELECT 
  CusttransOpen.ACCOUNTNUM,
  (Select VISTA_CANAL_CLIENTE.CANAL from VISTA_CANAL_CLIENTE where VISTA_CANAL_CLIENTE.ACCOUNTNUM=CUSTTRANS.ACCOUNTNUM) AS DIMENSION1,  
   (
  SELECT 
   DIRPARTYTABLE.NAME
FROM
  CUSTTABLE
  LEFT OUTER JOIN DIRPARTYTABLE ON (DIRPARTYTABLE.RECID = CUSTTABLE.PARTY)
WHERE
  CUSTTABLE.ACCOUNTNUM=CusttransOpen.ACCOUNTNUM
  and
  CUSTTABLE.DATAAREAID=CusttransOpen.DATAAREAID
  ) as nombre_cliente,
INVOICE= CASE  
			WHEN LEN(Custtrans.INVOICE)=0 
            THEN
            	(SELECT TOP 1 (SELECT   CUSTTRANS.INVOICE FROM  CUSTTRANS WHERE  CUSTTRANS.DATAAREAID = CustSettlement.TransCompany AND   CUSTTRANS.RECID =CustSettlement.TransRecId AND   CUSTTRANS.ACCOUNTNUM = CustSettlement.ACCOUNTNUM) FROM  custsettlement  where      custsettlement.OFFSETTRANSVOUCHER=CUSTTRANS.VOUCHER)
            ELSE
            Custtrans.INVOICE
            END,
   Custtrans.VOUCHER,
  TIPO = CASE 
  WHEN (Custtrans.Voucher LIKE 'ADLCC%') THEN 'CHEQUE POSTFECHADO'  
  WHEN (Custtrans.Voucher LIKE 'ADNDCL%') THEN 'NOTA DE DEBITO INTERNA'
  ELSE 'FACTURA NO DOCUMENTADA' END,
   datediff(day,custtransopen.DUEDATE,GETDATE()) dias_vencido,
   GRUPODIAS= CASE    
   WHEN datediff(day,custtransopen.DUEDATE,GETDATE())  <-120 THEN 'Vencidos Mas 120'
   WHEN datediff(day, custtransopen.DUEDATE,GETDATE()) BETWEEN -120 AND -89 THEN '-120 dias'
   WHEN datediff(day, custtransopen.DUEDATE,GETDATE()) BETWEEN -90 AND -59 THEN '-90 dias'
   WHEN datediff(day, custtransopen.DUEDATE,GETDATE()) BETWEEN -60 AND -29 THEN '-60 dias'
   WHEN datediff(day, custtransopen.DUEDATE,GETDATE()) BETWEEN -30 AND -1 THEN '-30 dias'
   WHEN datediff(day,custtransopen.duedate,GETDATE()) BETWEEN 1 AND 15 THEN '15 dias'
   WHEN datediff(day,custtransopen.duedate,GETDATE()) BETWEEN 16 AND 30  THEN '30 dias'
   WHEN datediff(day,custtransopen.duedate,GETDATE()) BETWEEN 31 AND 45 THEN '45 dias'
   WHEN datediff(day, custtransopen.duedate,GETDATE()) BETWEEN 46 AND 60 THEN '60 dias'
   WHEN datediff(day,custtransopen.duedate,GETDATE()) BETWEEN 61 AND 90 THEN '90 dias'
   WHEN datediff(day,custtransopen.duedate,GETDATE()) BETWEEN 91 AND 120 THEN '120 dias'
   WHEN datediff(day,custtransopen.duedate,GETDATE()) > 120 THEN 'Mayores a 120 dias'
   END,      
  CusttransOpen.TRANSDATE,
  CusttransOpen.DUEDATE,
  DESCRIPCION =(
  SELECT TOP 1 
  LedgerJournalTrans.TXT
FROM
  LedgerJournalTrans
WHERE
  LedgerJournalTrans.VOUCHER = Custtrans.VOUCHER
 -- AND
  --LedgerJournalTrans.CUSTTRANSID=CUSTTRANS.RECID
  AND
  LedgerJournalTrans.DATAAREAID='alph'
  ),

  DATEDIFF(day,CusttransOpen.TRANSDATE,CusttransOpen.DUEDATE) AS DiffDate,
 
  CusttransOpen.AMOUNTCUR
FROM
 CusttransOpen
  INNER JOIN Custtrans ON (CusttransOpen.ACCOUNTNUM = Custtrans.ACCOUNTNUM)
  AND (CusttransOpen.REFRECID = Custtrans.RECID)
  
WHERE
  CusttransOpen.DATAAREAID = 'alph'
  AND
  ( Custtrans.Voucher LIKE 'ADLCC%' OR Custtrans.Voucher LIKE 'ADNDCL%')
 -- AND 
 -- CUSTTRANSOPEN.ACCOUNTNUM = 'C000126'
)
  SELECT 
  ROW_NUMBER() OVER (ORDER BY (SELECT 1)) AS id,
  *
  FROM 
  ORIGEN
  /*
  PIVOT
  (
  SUM(AMOUNTCUR)
    FOR GRUPODIAS IN ([Vencidos Mas 120],[-120 dias],[-90 dias],[-60 dias],[-30 dias], [15 dias],[30 dias],[45 dias],[60 dias],[90 dias],[120 dias],[Mayores a 120 dias])

  )
  P
  */
