CREATE PROCEDURE dbo.LC_CustBalanceListDP
(
@fecha_limite DATE,
@accountnum2 nvarchar(20)
)
AS

BEGIN
 SET NOCOUNT ON;
 
 DECLARE
 @accountnum nvarchar(20), 
 @AMOUNTMST numeric(38, 16), 
 @EXCHADJUSTMENT numeric(38, 16),
 @SettleAmountMST numeric(32, 16)

 IF OBJECT_ID('tempdb..#custBalanceListTmp') IS NOT NULL
    BEGIN
        DROP TABLE #custBalanceListTmp
    END

 IF OBJECT_ID('tempdb..#custBalanceListTmpStaging1') IS NOT NULL
    BEGIN
        DROP TABLE #custBalanceListTmpStaging1
    END


 IF OBJECT_ID('tempdb..#custBalanceListTmpStaging2') IS NOT NULL
    BEGIN
        DROP TABLE #custBalanceListTmpStaging2
    END


SELECT 
  custtable.ACCOUNTNUM
  ,NOMBRE_CLIENTE=(Select VISTA_CANAL_CLIENTE.NOMBRECLIENTE from VISTA_CANAL_CLIENTE where custtable.ACCOUNTNUM=VISTA_CANAL_CLIENTE.ACCOUNTNUM )
  ,custtable.CREDITMAX
  ,custtable.MANDATORYCREDITLIMIT
  ,custtable.CREDITRATING
  ,custtable.BLOCKED
  INTO #custBalanceListTmp
FROM
  custtable
  where
  custtable.DATAAREAID='alph'
  AND
  custtable.ACCOUNTNUM=@accountnum2


SELECT 
  SUM(custTrans.AMOUNTMST) AS SUM_AMOUNTMST,
  custTrans.ACCOUNTNUM
  INTO #custBalanceListTmpStaging1
FROM
  custTrans
  where
    custTrans.TRANSDATE<=@fecha_limite
    AND
    custTrans.ACCOUNTNUM IN (Select ACCOUNTNUM from #custBalanceListTmp)
GROUP BY
  custTrans.ACCOUNTNUM


SELECT 
  SUM(custSettlement.EXCHADJUSTMENT) AS SUM_EXCHADJUSTMENT,
  sum(custSettlement.SettleAmountMST) AS SUM_SettleAmountMST,
  custSettlement.ACCOUNTNUM
  INTO #custBalanceListTmpStaging2 
FROM
  custSettlement
  WHERE
  custSettlement.TransDate<=@fecha_limite
  AND
  custSettlement.AccountNum in (Select ACCOUNTNUM from #custBalanceListTmp)
GROUP BY
  custSettlement.ACCOUNTNUM;
  
  
    Alter Table #custBalanceListTmp Add Balance numeric(32, 16);
    Alter Table #custBalanceListTmp Add AmountExceeded numeric(32, 16);
    
    
 --Ya que no puedo hacer outer join dentro de un update 
   
 /*
DROP TABLE DEL_custBalanceListTmp;
DROP TABLE DEL_custBalanceListTmpStaging1;
DROP TABLE DEL_custBalanceListTmpStaging2;
 */
 
 
DECLARE Index_CustBalanceListDP CURSOR FAST_FORWARD
FOR
  SELECT 
  #custBalanceListTmp.ACCOUNTNUM
  ,#custBalanceListTmpStaging1.SUM_AMOUNTMST
  ,#custBalanceListTmpStaging2.SUM_EXCHADJUSTMENT
  ,#custBalanceListTmpStaging2.SUM_SettleAmountMST
  FROM
  #custBalanceListTmpStaging1
  RIGHT OUTER JOIN #custBalanceListTmp ON (#custBalanceListTmpStaging1.ACCOUNTNUM = #custBalanceListTmp.ACCOUNTNUM)
  LEFT OUTER JOIN #custBalanceListTmpStaging2 ON (#custBalanceListTmp.ACCOUNTNUM = #custBalanceListTmpStaging2.ACCOUNTNUM)
 
 
-- Open the cursor for reading
OPEN Index_CustBalanceListDP;
-- Loop through all the tables in the database
FETCH NEXT FROM Index_CustBalanceListDP
INTO @accountnum, @AMOUNTMST, @EXCHADJUSTMENT,@SettleAmountMST;


WHILE @@FETCH_STATUS =0 
		BEGIN
        
        
        update #custBalanceListTmp 
        SET balance=ISNULL(@AMOUNTMST, 0) - (ISNULL(@SettleAmountMST, 0) - ISNULL(@EXCHADJUSTMENT, 0))
        where
        #custBalanceListTmp.ACCOUNTNUM=@accountnum;
        
        
         update #custBalanceListTmp
         set
          #custBalanceListTmp.AmountExceeded =ISNULL(balance,0) - ISNULL(CreditMax,0)
      --     where 
      --    #custBalanceListTmp.MandatoryCreditLimit=1
        
        
        
        -- Get the next index
        FETCH NEXT FROM Index_CustBalanceListDP
		INTO @accountnum, @AMOUNTMST, @EXCHADJUSTMENT,@SettleAmountMST;
        END
-- Close and deallocate the cursor.
CLOSE Index_CustBalanceListDP;
DEALLOCATE Index_CustBalanceListDP;

 
 

Select * from #custBalanceListTmp;
Select * from #custBalanceListTmpStaging1;
Select * from #custBalanceListTmpStaging2;

 IF OBJECT_ID('tempdb..#custBalanceListTmp') IS NOT NULL
    BEGIN
        DROP TABLE #custBalanceListTmp
    END

 IF OBJECT_ID('tempdb..#custBalanceListTmpStaging1') IS NOT NULL
    BEGIN
        DROP TABLE #custBalanceListTmpStaging1
    END


 IF OBJECT_ID('tempdb..#custBalanceListTmpStaging2') IS NOT NULL
    BEGIN
        DROP TABLE #custBalanceListTmpStaging2
    END


END
